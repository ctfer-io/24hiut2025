# Modèle d'Email B

## Objet
Confirmation de Votre Commande PopaCola

## Destinataire
Clients ayant passé une commande en ligne

## Contenu

Bonjour [Nom du Client],

Nous vous remercions pour votre commande sur notre site PopaCola. Voici un récapitulatif de votre achat :

- Produit : [Nom du Produit]
- Quantité : [Quantité]
- Total : [Prix Total] €

Votre commande sera expédiée sous 48 heures et vous recevrez un email de suivi dès son envoi.

Si vous avez des questions ou souhaitez apporter des modifications, n'hésitez pas à nous contacter à support@popacola.com.

Merci de votre confiance et à bientôt !

Cordialement,
L'équipe PopaCola

## Pièce Jointe
- Facture en PDF.
