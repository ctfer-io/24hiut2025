# Contrat de Partenariat B

## Parties
- PopaCola
- Designer Jean Dupont

## Objet
Collaboration pour la création d'une édition limitée de bouteilles PopaCola.

## Durée
- Début : 1er avril 2025
- Fin : 30 juin 2025

## Conditions
- Jean Dupont fournira un design unique pour les bouteilles.
- PopaCola produira 5 000 bouteilles collector.
- Partage des bénéfices à hauteur de 15% pour Jean Dupont.

## Obligations
- Jean Dupont : Respecter les délais de conception.
- PopaCola : Assurer la qualité de production.

## Résiliation
- Le contrat peut être résilié par l'une ou l'autre des parties avec un préavis de 30 jours.
- En cas de non-respect des obligations, résiliation immédiate.

## Signatures
- Pour PopaCola : [Nom et Signature]
- Pour Jean Dupont : [Nom et Signature]
