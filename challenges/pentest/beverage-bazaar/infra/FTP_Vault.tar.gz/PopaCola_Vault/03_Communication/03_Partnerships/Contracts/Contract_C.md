# Contrat de Partenariat C

## Parties
- PopaCola
- Chaîne de cinémas CinéPlus

## Objet
Partenariat pour des promotions estivales dans les cinémas.

## Durée
- Début : 1er juin 2025
- Fin : 31 juillet 2025

## Conditions
- CinéPlus offrira des espaces promotionnels dans ses cinémas.
- PopaCola fournira des produits pour les promotions.
- Partage des bénéfices à hauteur de 10% pour CinéPlus.

## Obligations
- CinéPlus : Promouvoir activement les offres PopaCola.
- PopaCola : Assurer la disponibilité des produits.

## Résiliation
- Le contrat peut être résilié par l'une ou l'autre des parties avec un préavis de 30 jours.
- En cas de non-respect des obligations, résiliation immédiate.

## Signatures
- Pour PopaCola : [Nom et Signature]
- Pour CinéPlus : [Nom et Signature]
