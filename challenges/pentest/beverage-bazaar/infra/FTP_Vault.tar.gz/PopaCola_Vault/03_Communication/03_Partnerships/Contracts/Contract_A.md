# Contrat de Partenariat A

## Parties
- PopaCola
- Supermarché XYZ

## Objet
Partenariat pour la distribution exclusive de PopaCola dans les magasins XYZ.

## Durée
- Début : 1er avril 2025
- Fin : 31 mars 2026

## Conditions
- PopaCola fournira un stock mensuel de 10 000 bouteilles.
- Supermarché XYZ s'engage à mettre en avant les produits PopaCola.
- Partage des bénéfices à hauteur de 10% pour PopaCola.

## Obligations
- PopaCola : Assurer la qualité des produits et les livraisons dans les délais.
- Supermarché XYZ : Promouvoir activement les produits PopaCola.

## Résiliation
- Le contrat peut être résilié par l'une ou l'autre des parties avec un préavis de 30 jours.
- En cas de non-respect des obligations, résiliation immédiate.

## Signatures
- Pour PopaCola : [Nom et Signature]
- Pour Supermarché XYZ : [Nom et Signature]
