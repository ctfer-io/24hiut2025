# Modèle d'Email A

## Objet
Invitation à l'Événement de Lancement de PopaCola Tropical

## Destinataire
Partenaires et Clients VIP

## Contenu

Chers [Nom du Destinataire],

Nous avons le plaisir de vous inviter à l'événement de lancement de notre nouvelle saveur estivale : PopaCola Tropical. Venez découvrir cette boisson rafraîchissante et passer un moment convivial avec nous.

- Date : 1er avril 2025
- Heure : 18h00
- Lieu : Salle des Fêtes, Paris

Au programme :
- Dégustation de PopaCola Tropical.
- Animations et surprises.
- Rencontre avec l'équipe PopaCola.

Merci de confirmer votre présence avant le 25 mars en répondant à cet email.

Nous espérons vous voir nombreux !

Cordialement,
L'équipe PopaCola

## Pièce Jointe
- Invitation officielle en PDF.
