# Modèle d'Email C

## Objet
Invitation à Participer à Notre Enquête de Satisfaction

## Destinataire
Clients récents

## Contenu

Bonjour [Nom du Client],

Nous espérons que vous appréciez votre expérience avec PopaCola. Pour continuer à améliorer nos produits et services, nous aimerions connaître votre avis.

Participez à notre enquête de satisfaction en cliquant sur le lien ci-dessous :
[Lien vers l'enquête]

Votre retour est précieux et nous permettra de mieux répondre à vos attentes. L'enquête ne prendra que quelques minutes de votre temps.

Merci pour votre participation !

Cordialement,
L'équipe PopaCola

## Note
Vos réponses resteront confidentielles et seront utilisées uniquement à des fins d'amélioration.
