# Projet de Collaboration B

## Titre
Création d'une édition limitée avec un designer de renom

## Objectif
Lancer une bouteille collector en collaboration avec un designer reconnu.

## Partenaires
- Designer : Jean Dupont
- PopaCola : Équipe Marketing et Design

## Calendrier
- Avril : Conception du design.
- Mai : Production des prototypes.
- Juin : Lancement de l'édition limitée.

## Budget
- Design : 8 000 €
- Production : 15 000 €
- Marketing : 5 000 €

## Livrables
- 5 000 bouteilles collector.
- Campagne de lancement sur les réseaux sociaux.
- Événement de lancement avec le designer.

## Risques
- Délais de production.
- Réception du design par le public.

## Suivi
- Réunions hebdomadaires pour suivre l'avancement.
- Rapport final à la fin du projet.
