# Projet de Collaboration A

## Titre
Développement d'une édition limitée avec un artiste local

## Objectif
Créer une bouteille collector en collaboration avec un artiste renommé.

## Partenaires
- Artiste : Léa Martin
- PopaCola : Équipe Marketing et Design

## Calendrier
- Janvier : Conception du design.
- Février : Production des prototypes.
- Mars : Lancement de l'édition limitée.

## Budget
- Design : 5 000 €
- Production : 10 000 €
- Marketing : 3 000 €

## Livrables
- 5 000 bouteilles collector.
- Campagne de lancement sur les réseaux sociaux.
- Événement de lancement avec l'artiste.

## Risques
- Délais de production.
- Réception du design par le public.

## Suivi
- Réunions hebdomadaires pour suivre l'avancement.
- Rapport final à la fin du projet.
