# Ticket de Support C

## ID du Ticket
SUP-003

## Date
25 mars 2025

## Client
Paul Leclerc

## Problème
Le client n'a pas reçu sa commande dans les délais prévus.

## Actions Entreprises
- Vérification du statut de livraison.
- Contact avec le transporteur pour localiser le colis.
- Envoi d'un nouveau colis avec livraison express.

## Statut
En cours

## Commentaires
Le client a été informé des démarches en cours et sera tenu au courant de l'évolution.
