# Rapport d'Engagement sur les Réseaux Sociaux B

## Période
Avril - Juin 2025

## Plateformes
- Instagram
- Facebook
- Twitter

## Résultats
- Instagram : +15% d'abonnés, taux d'engagement de 6%.
- Facebook : +10% de likes, portée des publications augmentée de 15%.
- Twitter : +5% de followers, interactions en hausse de 10%.

## Campagnes Réussies
- Campagne "Été 2025" : forte participation au concours.
- Lancement de la saveur Tropical : buzz positif et partages nombreux.

## Points à Améliorer
- Réactivité aux commentaires et messages privés.
- Diversification des types de contenu (vidéos, stories).

## Recommandations
- Augmenter la fréquence des publications.
- Collaborer avec des influenceurs pour toucher un public plus large.
- Utiliser davantage de vidéos courtes et dynamiques.
