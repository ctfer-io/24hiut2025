# Rapport d'Engagement sur les Réseaux Sociaux

## Période
Janvier - Mars 2025

## Plateformes
- Instagram
- Facebook
- Twitter

## Résultats
- Instagram : +20% d'abonnés, taux d'engagement de 5%.
- Facebook : +15% de likes, portée des publications augmentée de 10%.
- Twitter : +10% de followers, interactions en hausse de 8%.

## Campagnes Réussies
- Campagne "Nouvelle Année" : forte participation au concours.
- Lancement de la saveur Tropical : buzz positif et partages nombreux.

## Points à Améliorer
- Réactivité aux commentaires et messages privés.
- Diversification des types de contenu (vidéos, stories).

## Recommandations
- Augmenter la fréquence des publications.
- Collaborer avec des influenceurs pour toucher un public plus large.
- Utiliser davantage de vidéos courtes et dynamiques.
