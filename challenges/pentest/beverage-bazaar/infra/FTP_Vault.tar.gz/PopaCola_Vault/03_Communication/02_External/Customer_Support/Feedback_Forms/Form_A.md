# Formulaire de Feedback A

## Questions

1. Comment évaluez-vous la qualité de notre produit ?
   - Excellente
   - Bonne
   - Moyenne
   - Mauvaise

2. Quelle saveur de PopaCola préférez-vous ?
   - Originale
   - Cerise
   - Citron
   - Tropical

3. Avez-vous rencontré des problèmes avec votre commande ?
   - Oui
   - Non

4. Recommanderiez-vous PopaCola à un ami ?
   - Oui
   - Non

5. Avez-vous des suggestions pour améliorer notre service ?
   - [Champ de texte libre]

## Instructions
Merci de remplir ce formulaire pour nous aider à améliorer nos produits et services. Vos retours sont précieux !
