# Ticket de Support B

## ID du Ticket
SUP-002

## Date
20 mars 2025

## Client
Marie Dubois

## Problème
Le client a reçu une bouteille endommagée dans sa commande.

## Actions Entreprises
- Vérification de la commande dans le système.
- Envoi d'une nouvelle bouteille au client.
- Offre d'une réduction sur la prochaine commande.

## Statut
Résolu

## Commentaires
Le client a été informé de l'envoi de la nouvelle bouteille et s'est montré satisfait de la réponse rapide.
