# Formulaire de Feedback B

## Questions

1. Comment évaluez-vous la qualité de notre service client ?
   - Excellente
   - Bonne
   - Moyenne
   - Mauvaise

2. Avez-vous rencontré des problèmes avec votre commande ?
   - Oui
   - Non

3. Recommanderiez-vous PopaCola à un ami ?
   - Oui
   - Non

4. Avez-vous des suggestions pour améliorer notre service ?
   - [Champ de texte libre]

## Instructions
Merci de remplir ce formulaire pour nous aider à améliorer nos services. Vos retours sont précieux !
