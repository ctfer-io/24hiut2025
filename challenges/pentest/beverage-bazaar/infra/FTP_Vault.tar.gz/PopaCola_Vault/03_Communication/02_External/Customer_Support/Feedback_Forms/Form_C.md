# Formulaire de Feedback C

## Questions

1. Quelle saveur de PopaCola préférez-vous ?
   - Originale
   - Cerise
   - Citron
   - Tropical

2. Comment évaluez-vous la disponibilité de nos produits ?
   - Toujours disponible
   - Souvent disponible
   - Parfois disponible
   - Rarement disponible

3. Avez-vous des suggestions pour de nouvelles saveurs ?
   - [Champ de texte libre]

## Instructions
Merci de remplir ce formulaire pour nous aider à améliorer nos produits. Vos retours sont précieux !
