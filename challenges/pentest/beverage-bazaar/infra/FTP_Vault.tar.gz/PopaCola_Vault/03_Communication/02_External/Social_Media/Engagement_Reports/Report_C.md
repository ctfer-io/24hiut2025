# Rapport d'Engagement sur les Réseaux Sociaux C

## Période
Juillet - Septembre 2025

## Plateformes
- Instagram
- Facebook
- Twitter

## Résultats
- Instagram : +20% d'abonnés, taux d'engagement de 7%.
- Facebook : +12% de likes, portée des publications augmentée de 20%.
- Twitter : +7% de followers, interactions en hausse de 15%.

## Campagnes Réussies
- Campagne "Rentrée Scolaire" : forte participation au concours.
- Lancement de la nouvelle bouteille écologique : retours positifs.

## Points à Améliorer
- Réactivité aux commentaires et messages privés.
- Diversification des types de contenu (vidéos, stories).

## Recommandations
- Augmenter la fréquence des publications.
- Collaborer avec des influenceurs pour toucher un public plus large.
- Utiliser davantage de vidéos courtes et dynamiques.
