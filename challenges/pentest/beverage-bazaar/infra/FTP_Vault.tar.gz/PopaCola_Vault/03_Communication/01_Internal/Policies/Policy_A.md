# Politique de Confidentialité des Données

## Objectif
Protéger les données personnelles des clients et des employés.

## Portée
Cette politique s'applique à toutes les données collectées, stockées et traitées par PopaCola.

## Principes
- Les données personnelles doivent être collectées de manière légale et transparente.
- Les données doivent être utilisées uniquement pour les finalités déclarées.
- Les données doivent être protégées contre tout accès non autorisé.

## Responsabilités
- Le responsable de la protection des données est chargé de la mise en œuvre de cette politique.
- Tous les employés doivent suivre les procédures de protection des données.

## Procédures
- Les données personnelles doivent être stockées dans des systèmes sécurisés.
- Les accès aux données doivent être limités aux personnes autorisées.
- Les incidents de sécurité doivent être signalés immédiatement.

## Formation
- Tous les employés doivent suivre une formation annuelle sur la protection des données.
- Des sessions de sensibilisation seront organisées régulièrement.

## Révision
- Cette politique sera révisée annuellement pour s'assurer de sa conformité avec les réglementations en vigueur.
