# Politique de Remboursement des Frais

## Objectif
Définir les modalités de remboursement des frais professionnels.

## Portée
Cette politique s'applique à tous les employés de PopaCola.

## Frais Éligibles
- Déplacements professionnels (transport, hébergement).
- Repas d'affaires.
- Fournitures de bureau.

## Procédure de Remboursement
- Les employés doivent soumettre une demande de remboursement via le portail interne.
- Les justificatifs (factures, reçus) doivent être joints à la demande.
- Les remboursements seront effectués dans un délai de 15 jours ouvrables.

## Limites
- Les frais de repas sont plafonnés à 25 € par jour.
- Les frais d'hébergement doivent être raisonnables et justifiés.

## Responsabilités
- Les managers doivent approuver les demandes de remboursement.
- Le service comptabilité traite les remboursements.

## Contrôles
- Des audits réguliers seront effectués pour vérifier la conformité des demandes.
- Les abus seront sanctionnés conformément à la politique disciplinaire.
