# Politique de Télétravail

## Objectif
Encadrer le télétravail pour les employés de PopaCola.

## Portée
Cette politique s'applique à tous les employés éligibles au télétravail.

## Principes
- Le télétravail est autorisé jusqu'à 3 jours par semaine.
- Les employés doivent disposer d'un espace de travail adapté.
- Les horaires de travail restent les mêmes qu'au bureau.

## Responsabilités
- Les managers doivent approuver les demandes de télétravail.
- Les employés doivent respecter les procédures de sécurité informatique.

## Procédures
- Les demandes de télétravail doivent être soumises au moins une semaine à l'avance.
- Les employés doivent être joignables pendant leurs heures de travail.
- Les réunions d'équipe doivent être maintenues via des outils de visioconférence.

## Équipement
- PopaCola fournit un ordinateur portable et les outils nécessaires.
- Les employés doivent disposer d'une connexion internet stable.

## Évaluation
- La performance des employés en télétravail sera évaluée régulièrement.
- Des ajustements pourront être faits en fonction des retours.
