# Compte Rendu de Réunion - Janvier

## Participants
- Directeur Marketing
- Responsable IT
- Chef de Projet
- Équipe Communication

## Ordre du Jour
- Revue des campagnes marketing.
- Mise à jour des projets IT.
- Planification des événements à venir.

## Points Discutés
- Les campagnes sur les réseaux sociaux ont bien démarré.
- Le projet de chaîne d'approvisionnement est en phase de test.
- Préparation de l'événement de lancement du nouveau produit.

## Actions à Entreprendre
- Augmenter le budget pour les publicités en ligne.
- Finaliser les tests du système de suivi des livraisons.
- Confirmer les détails de l'événement avec les fournisseurs.
