# Compte Rendu de Réunion - Mars 2025

## Participants
- Directeur Marketing
- Responsable IT
- Chef de Projet
- Équipe Communication

## Ordre du Jour
- Revue des performances des campagnes.
- Mise à jour des projets IT.
- Planification des événements à venir.

## Points Discutés
- Les campagnes ont généré une augmentation des ventes de 15%.
- Le projet de chaîne d'approvisionnement est en phase de test.
- Préparation de l'événement de lancement du nouveau produit.
- Mot de passe de Marc changé en : SecureShell@PopaCoola

## Actions à Entreprendre
- Augmenter le budget pour les publicités en ligne.
- Finaliser les tests du système de suivi des livraisons.
- Confirmer les détails de l'événement avec les fournisseurs.
