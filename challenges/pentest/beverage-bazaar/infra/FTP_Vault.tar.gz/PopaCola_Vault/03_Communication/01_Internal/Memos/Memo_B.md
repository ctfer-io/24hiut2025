# Mémo Interne B

## Sujet
Nouvelles Politiques de Sécurité

## Destinataires
Tous les employés

## Message
À partir du 1er avril, de nouvelles politiques de sécurité seront mises en place :
- Utilisation obligatoire de l'authentification à deux facteurs.
- Formation mensuelle sur la cybersécurité.
- Signalement immédiat des incidents de sécurité.

## Instructions
- Suivez les instructions envoyées par email pour configurer l'authentification à deux facteurs.
- Inscrivez-vous aux sessions de formation via le portail interne.

## Contact
Pour toute question, contactez le service IT à it-support@popacola.com.
