# Mémo Interne A

## Sujet
Nouvelles Mesures de Sécurité IT

## Destinataires
Tous les employés

## Message
À partir du 1er mars, de nouvelles mesures de sécurité seront mises en place :
- Changement obligatoire des mots de passe tous les 3 mois.
- Utilisation de l'authentification à deux facteurs.
- Formation obligatoire sur la cybersécurité.

## Instructions
- Veuillez suivre les instructions envoyées par email pour mettre à jour vos mots de passe.
- Assurez-vous de configurer l'authentification à deux facteurs avant la date limite.
- Inscrivez-vous à la session de formation via le portail interne.

## Contact
Pour toute question, contactez le service IT à it-support@popacola.com.
