# Mémo Interne C

## Sujet
Réorganisation des Équipes

## Destinataires
Tous les employés

## Message
Pour améliorer notre efficacité, une réorganisation des équipes sera mise en place :
- Création d'une équipe dédiée à l'innovation produit.
- Renforcement de l'équipe marketing digital.
- Nouveaux rôles de leadership au sein des équipes.

## Instructions
- Les nouveaux rôles et responsabilités seront communiqués lors de la réunion du 15 avril.
- Les employés concernés seront contactés individuellement.

## Contact
Pour toute question, contactez le service RH à hr@popacola.com.
