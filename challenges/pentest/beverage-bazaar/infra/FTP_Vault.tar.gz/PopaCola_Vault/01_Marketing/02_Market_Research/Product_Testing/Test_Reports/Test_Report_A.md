# Rapport de Test A

## Objectif
Tester la nouvelle formule de PopaCola sans sucre.

## Méthodologie
- Panel de 50 consommateurs.
- Test à l'aveugle comparé à la formule originale.
- Questionnaire de satisfaction.

## Résultats
- 60% des testeurs préfèrent la nouvelle formule.
- 30% n'ont pas remarqué de différence.
- 10% préfèrent la formule originale.

## Conclusion
- La nouvelle formule est bien accueillie.
- Quelques ajustements mineurs sont nécessaires.
- Préparation du lancement sur le marché.
