# Rapport de Test B

## Objectif
Évaluer la résistance des nouvelles bouteilles en plastique recyclé.

## Méthodologie
- Tests de pression et de chute.
- Évaluation de la durabilité après exposition au soleil.
- Questionnaire de satisfaction auprès des utilisateurs.

## Résultats
- Les bouteilles résistent à une pression de 5 bars.
- Aucune fissure après des chutes de 1,5 mètre.
- 90% des utilisateurs trouvent les bouteilles solides et agréables à utiliser.

## Conclusion
- Les nouvelles bouteilles répondent aux exigences de durabilité.
- Quelques ajustements mineurs pour améliorer la résistance aux UV.
- Préparation pour la production à grande échelle.
