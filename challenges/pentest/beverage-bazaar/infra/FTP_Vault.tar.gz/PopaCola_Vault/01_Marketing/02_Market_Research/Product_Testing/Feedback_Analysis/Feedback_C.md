# Feedback Client C

## Informations Générales
- Nom : Sophie Lemaire
- Date : 20 juin 2025

## Commentaires
- "Les événements de nettoyage sont une belle initiative."
- "Les stands dans les festivals étaient très interactifs."
- "La qualité des produits est toujours au rendez-vous."

## Suggestions
- "Organiser plus d'événements communautaires."
- "Proposer des réductions pour les achats en gros."

## Note
- Satisfaction globale : 9/10
