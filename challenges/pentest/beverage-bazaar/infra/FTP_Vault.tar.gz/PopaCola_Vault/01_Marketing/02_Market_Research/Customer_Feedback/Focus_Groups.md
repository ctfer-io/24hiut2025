# Focus Groups

## Objectif
Recueillir des avis détaillés sur les nouvelles initiatives écologiques de PopaCola.

## Participants
- 10 consommateurs réguliers de PopaCola.
- 5 consommateurs occasionnels.

## Retours
- Appréciation générale des initiatives écologiques.
- Suggestion d'utiliser des matériaux recyclés pour les emballages.
- Intérêt pour des campagnes de sensibilisation environnementale.

## Actions à Entreprendre
- Communiquer davantage sur les engagements écologiques.
- Envisager des partenariats avec des organisations environnementales.
- Organiser des événements de sensibilisation.
