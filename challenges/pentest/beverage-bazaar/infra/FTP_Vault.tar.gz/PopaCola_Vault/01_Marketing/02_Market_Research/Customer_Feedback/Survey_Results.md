# Résultats de l'Enquête

## Satisfaction Générale
- 80% des répondants sont satisfaits de PopaCola.
- 15% sont neutres.
- 5% sont insatisfaits.

## Préférences de Saveur
- Saveur originale : 50%
- Saveur cerise : 30%
- Saveur citron : 20%

## Suggestions d'Amélioration
- Ajouter de nouvelles saveurs.
- Améliorer la disponibilité dans les magasins.
- Réduire la quantité de sucre.

## Commentaires
- "J'adore PopaCola, surtout la saveur cerise !"
- "Il serait bien d'avoir des options sans sucre."
- "Difficile à trouver dans certains magasins."
