# Analyse de FreizhCola

## Forces
- Forte notoriété locale.
- Gamme de produits diversifiée.
- Stratégie de marketing agressive.

## Faiblesses
- Distribution limitée à certaines régions.
- Budget publicitaire inférieur à celui de PopaCola.
- Moins de partenariats avec des influenceurs.

## Opportunités
- Expansion dans de nouvelles régions.
- Augmentation du budget publicitaire.
- Collaboration avec des influenceurs locaux.

## Menaces
- Concurrence accrue de PopaCola.
- Changements dans les préférences des consommateurs.
- Augmentation des coûts des matières premières.
