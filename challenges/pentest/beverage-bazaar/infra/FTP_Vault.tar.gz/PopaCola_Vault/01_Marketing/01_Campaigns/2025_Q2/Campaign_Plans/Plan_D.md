# Plan de Campagne D

## Objectif
Promouvoir les engagements écologiques de PopaCola.

## Stratégie
- Utiliser les réseaux sociaux pour sensibiliser à l'impact environnemental.
- Collaborer avec des influenceurs engagés dans la protection de l'environnement.
- Organiser des événements de nettoyage communautaire.

## Actions
- Créer des visuels mettant en avant les initiatives écologiques de PopaCola.
- Lancer une campagne de hashtag #PopaColaEco.
- Publier des témoignages de consommateurs engagés.

## Budget
- Publicité en ligne : 8 000 €
- Événements : 4 000 €
- Influenceurs : 3 000 €

## Calendrier
- Avril : Préparation des visuels et des messages.
- Mai : Lancement de la campagne sur les réseaux sociaux.
- Juin : Organisation des événements de nettoyage.
