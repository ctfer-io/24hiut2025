# Plan de Campagne B

## Objectif
Promouvoir la nouvelle saveur de PopaCola auprès des familles.

## Stratégie
- Publicité télévisée pendant les heures de grande écoute.
- Partenariats avec des chaînes de supermarchés.
- Offres promotionnelles pour les achats en gros.

## Actions
- Tournage de spots publicitaires mettant en scène des familles.
- Distribution d'échantillons gratuits dans les magasins.
- Création de packs familiaux avec des réductions.

## Budget
- Publicité TV : 20 000 €
- Échantillons : 2 000 €
- Packs promotionnels : 3 000 €

## Calendrier
- Janvier : Tournage des spots
- Février : Diffusion des publicités
- Mars : Distribution des échantillons
