# Plan de Campagne E

## Objectif
Augmenter la visibilité de PopaCola lors des festivals d'été.

## Stratégie
- Sponsoring de festivals de musique et d'événements culturels.
- Distribution d'échantillons gratuits lors des festivals.
- Création de stands interactifs pour engager le public.

## Actions
- Négocier des contrats de sponsoring avec les organisateurs de festivals.
- Préparer des stands avec des activités ludiques et des dégustations.
- Utiliser les réseaux sociaux pour promouvoir la présence de PopaCola aux festivals.

## Budget
- Sponsoring : 15 000 €
- Stands et activités : 5 000 €
- Publicité en ligne : 3 000 €

## Calendrier
- Mai : Négociations et préparations.
- Juin : Installation des stands dans les festivals.
- Juillet : Lancement des publicités en ligne.
