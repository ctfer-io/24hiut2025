# Plan de Campagne F

## Objectif
Renforcer la présence de PopaCola dans les établissements scolaires.

## Stratégie
- Partenariats avec des écoles et des universités pour des événements sportifs.
- Distribution de bouteilles de PopaCola lors des compétitions scolaires.
- Organisation de concours pour les étudiants.

## Actions
- Contacter les responsables des établissements scolaires pour proposer des partenariats.
- Fournir des bouteilles de PopaCola pour les événements sportifs.
- Lancer des concours sur les réseaux sociaux pour les étudiants.

## Budget
- Partenariats : 10 000 €
- Fournitures : 4 000 €
- Concours et récompenses : 2 000 €

## Calendrier
- Avril : Prise de contact et négociations.
- Mai : Fourniture des produits pour les événements.
- Juin : Lancement des concours.
