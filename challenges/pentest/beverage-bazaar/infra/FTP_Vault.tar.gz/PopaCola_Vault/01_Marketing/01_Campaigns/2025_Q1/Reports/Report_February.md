# Rapport de Campagne - Février

## Résumé
Le mois de février a vu le lancement des campagnes sur les réseaux sociaux et à la télévision.

## Actions Réalisées
- Lancement de la campagne sur Instagram et TikTok.
- Diffusion des spots publicitaires à la télévision.
- Installation des stands dans 3 stades.

## Résultats
- Engagement élevé sur les réseaux sociaux.
- Retour positif des téléspectateurs sur les spots publicitaires.
- Succès des stands avec une forte participation.

## Prochaines Étapes
- Analyser les résultats des campagnes.
- Ajuster les stratégies en fonction des retours.
- Préparer la distribution des échantillons.
