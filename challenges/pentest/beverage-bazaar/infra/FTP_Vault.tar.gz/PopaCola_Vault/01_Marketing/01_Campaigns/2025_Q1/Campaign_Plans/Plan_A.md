# Plan de Campagne A

## Objectif
Augmenter la notoriété de la marque PopaCola auprès des jeunes adultes.

## Stratégie
- Utiliser les réseaux sociaux pour des campagnes ciblées.
- Collaborer avec des influenceurs locaux.
- Organiser des événements dans les universités.

## Actions
- Créer des visuels attrayants pour Instagram et TikTok.
- Lancer un concours avec des lots attractifs.
- Publier des témoignages de consommateurs satisfaits.

## Budget
- Publicité en ligne : 10 000 €
- Événements : 5 000 €
- Influenceurs : 3 000 €

## Calendrier
- Janvier : Préparation des visuels
- Février : Lancement de la campagne
- Mars : Analyse des résultats et ajustements
