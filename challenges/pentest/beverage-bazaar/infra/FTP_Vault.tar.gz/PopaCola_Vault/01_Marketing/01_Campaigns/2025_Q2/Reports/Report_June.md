# Rapport de Campagne - Juin

## Résumé
Le mois de juin a été marqué par l'organisation des événements de nettoyage et les concours étudiants.

## Actions Réalisées
- Organisation de 3 événements de nettoyage communautaire.
- Lancement des concours sur les réseaux sociaux pour les étudiants.
- Distribution d'échantillons gratuits dans les festivals.

## Résultats
- Forte participation aux événements de nettoyage.
- Engagement élevé des étudiants dans les concours.
- Succès de la distribution des échantillons.

## Prochaines Étapes
- Préparer le rapport final des campagnes.
- Évaluer l'impact des initiatives écologiques.
- Planifier les prochaines campagnes pour l'automne.
