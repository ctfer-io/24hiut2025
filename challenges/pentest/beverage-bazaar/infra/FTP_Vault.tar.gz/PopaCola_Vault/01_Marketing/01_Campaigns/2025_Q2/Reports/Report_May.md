# Rapport de Campagne - Mai

## Résumé
Le mois de mai a vu le lancement des campagnes sur les réseaux sociaux et dans les festivals.

## Actions Réalisées
- Lancement de la campagne écologique sur Instagram et TikTok.
- Installation des stands dans 3 festivals.
- Distribution de bouteilles de PopaCola lors des événements scolaires.

## Résultats
- Engagement élevé sur les réseaux sociaux.
- Succès des stands avec une forte participation.
- Retour positif des étudiants sur les concours.

## Prochaines Étapes
- Analyser les résultats des campagnes.
- Ajuster les stratégies en fonction des retours.
- Préparer la distribution des échantillons.
