# Rapport de Campagne - Avril

## Résumé
Le mois d'avril a été consacré à la préparation des campagnes estivales.

## Actions Réalisées
- Création de 10 visuels pour les réseaux sociaux.
- Négociation de 5 contrats de sponsoring avec des festivals.
- Préparation des stands pour les événements scolaires.

## Résultats
- Les visuels ont reçu un bon accueil en interne.
- Les contrats de sponsoring sont en phase de finalisation.
- Les stands sont prêts pour les événements de mai.

## Prochaines Étapes
- Lancer les campagnes sur les réseaux sociaux.
- Installer les stands dans les festivals.
- Organiser les concours pour les étudiants.
