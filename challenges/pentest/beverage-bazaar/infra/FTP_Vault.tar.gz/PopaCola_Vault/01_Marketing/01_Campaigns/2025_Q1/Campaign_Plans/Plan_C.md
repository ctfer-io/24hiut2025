# Plan de Campagne C

## Objectif
Renforcer la présence de PopaCola dans les événements sportifs.

## Stratégie
- Sponsoring d'équipes locales.
- Stands de dégustation lors des matchs.
- Publicité sur les panneaux d'affichage des stades.

## Actions
- Négociation de contrats de sponsoring.
- Préparation des stands et des échantillons.
- Création de visuels pour les panneaux d'affichage.

## Budget
- Sponsoring : 15 000 €
- Stands : 4 000 €
- Panneaux d'affichage : 3 000 €

## Calendrier
- Janvier : Négociations et préparations
- Février : Installation des stands
- Mars : Lancement des publicités
