# Publicité Imprimée B

## Contenu
- **Titre :** Offre Spéciale : Pack Famille PopaCola !
- **Sous-titre :** Économisez en achetant en gros pour toute la famille.
- **Description :** Profitez de notre offre spéciale avec 6 bouteilles de PopaCola à un prix réduit. Idéal pour les fêtes et les réunions de famille.
- **Image :** Une image attrayante du pack famille avec les bouteilles disposées de manière festive.
- **Appel à l'Action :** Disponible dans tous vos supermarchés. Ne manquez pas cette offre limitée !
- **Informations de Contact :** Pour plus d'informations, visitez notre site web ou contactez-nous à info@popacola.com.

## Format
- Taille : A4
- Couleurs : Utilisation de couleurs vives pour attirer l'attention.
- Police : Moderne et lisible.

## Instructions d'Impression
- Imprimer en haute résolution pour une meilleure qualité.
- Utiliser du papier glacé pour un rendu professionnel.
