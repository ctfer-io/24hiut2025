# Protocole de Sécurité C

## Objectif
Assurer la sécurité des données sensibles de l'entreprise.

## Mesures
- Chiffrement des données en transit et au repos.
- Authentification à deux facteurs pour tous les accès.
- Surveillance continue des activités suspectes.

## Responsabilités
- Administrateurs système : Mise en œuvre et surveillance.
- Employés : Respect des procédures de sécurité.

## Procédures
- Signaler immédiatement toute activité suspecte.
- Effectuer des audits de sécurité trimestriels.
- Former régulièrement les employés aux bonnes pratiques de sécurité.
