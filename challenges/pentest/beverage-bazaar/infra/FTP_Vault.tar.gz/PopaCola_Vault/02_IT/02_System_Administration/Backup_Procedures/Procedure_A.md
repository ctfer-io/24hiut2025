# Procédure de Sauvegarde des Données

## Objectif
Assurer la sauvegarde régulière et sécurisée des données de PopaCola.

## Fréquence
- Sauvegarde complète : Mensuelle
- Sauvegarde incrémentale : Quotidienne

## Étapes
1. Vérifier l'intégrité des données avant la sauvegarde.
2. Lancer le script de sauvegarde automatique.
3. Transférer les sauvegardes vers le serveur externe.
4. Vérifier la réussite de la sauvegarde et la restauration des données.

## Responsabilités
- Le responsable IT est chargé de la supervision des sauvegardes.
- Les administrateurs système doivent vérifier quotidiennement les rapports de sauvegarde.

## Tests
- Tests de restauration mensuels pour vérifier l'intégrité des sauvegardes.
- Simulations de perte de données pour évaluer la procédure de récupération.
