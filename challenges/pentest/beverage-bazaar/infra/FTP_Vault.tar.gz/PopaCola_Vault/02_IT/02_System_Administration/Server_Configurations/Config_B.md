# Configuration du Serveur B

## Spécifications
- Système d'exploitation : Linux Ubuntu 22.04
- CPU : Intel Xeon 16 cœurs
- RAM : 64 Go
- Stockage : 2 To SSD

## Rôles
- Serveur de base de données principal.
- Hébergement des applications internes.

## Sécurité
- Pare-feu configuré pour bloquer les accès non autorisés.
- Chiffrement des disques.
- Sauvegardes automatiques quotidiennes.
