# Configuration du Serveur C

## Spécifications
- Système d'exploitation : Windows Server 2022
- CPU : AMD Ryzen 12 cœurs
- RAM : 32 Go
- Stockage : 1 To SSD

## Rôles
- Serveur de fichiers pour les départements marketing et communication.
- Hébergement des outils de collaboration.

## Sécurité
- Antivirus et anti-malware actifs.
- Contrôle d'accès basé sur les rôles.
- Sauvegardes incrémentielles toutes les 6 heures.
