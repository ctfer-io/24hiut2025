# Compte Utilisateur C

## Informations
- Nom : Sophie Leclerc
- Rôle : Administratrice Système
- Username : sleclerc
- Email : sophie.leclerc@popacola.com
- Mot de Passe : AdminSophie@2025

## Permissions
- Accès complet aux systèmes d'information.
- Droits d'administration sur tous les serveurs.
- Accès aux journaux de sécurité.
