# Configuration du Serveur A

## Spécifications Matérielles
- Processeur : Intel Xeon, 3.5 GHz
- Mémoire : 64 Go RAM
- Stockage : 2 To SSD

## Système d'Exploitation
- OS : Ubuntu Server 22.04 LTS
- Kernel : 5.15.0

## Services
- Apache2 : Serveur web
- MySQL : Base de données
- SSH : Accès distant sécurisé

## Sauvegarde
- Fréquence : Quotidienne
- Destination : Serveur de sauvegarde externe

## Sécurité
- Pare-feu : UFW activé
- Mises à jour : Automatiques, vérifiées quotidiennement
