# Procédure de Sauvegarde B

## Objectif
Assurer la restauration des données en cas de panne.

## Fréquence
- Sauvegardes incrémentielles quotidiennes.
- Sauvegardes complètes hebdomadaires.

## Stockage
- Serveurs locaux avec redondance.
- Cloud pour les sauvegardes critiques.

## Responsabilités
- Administrateurs système : Vérification des sauvegardes.
- Équipe IT : Restauration des données en cas de besoin.

## Tests
- Tests de restauration mensuels.
- Rapports d'intégrité des sauvegardes.
