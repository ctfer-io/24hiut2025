# Compte Utilisateur B

## Informations
- Nom : Marc Dupuis
- Rôle : Développeur Fullstack Senior
- Username : mdupuis
- Email : marc.dupuis@popacola.com
- Mot de Passe : SecureDev@Marc2025

## Permissions
- Accès complet aux environnements de développement.
- Droits d'administration sur les serveurs de test.
- Accès aux dépôts de code source.
