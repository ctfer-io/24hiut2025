# Procédure de Sauvegarde C

## Objectif
Garantir la disponibilité des données en cas de sinistre.

## Fréquence
- Sauvegardes incrémentielles toutes les 4 heures.
- Sauvegardes complètes mensuelles.

## Stockage
- Serveurs externes sécurisés.
- Copies physiques pour les données sensibles.

## Responsabilités
- Administrateurs système : Surveillance des sauvegardes.
- Équipe IT : Mise à jour des plans de restauration.

## Tests
- Simulations de sinistre trimestrielles.
- Mises à jour des procédures basées sur les retours des tests.
