# Compte Utilisateur A

## Informations
- Nom : Alice Martin
- Rôle : Responsable Marketing
- Username : amartin
- Email : alice.martin@popacola.com
- Mot de Passe : P@ssw0rdAlice2025

## Permissions
- Accès complet aux outils de marketing.
- Lecture seule sur les rapports financiers.
- Accès aux fichiers de campagne.
