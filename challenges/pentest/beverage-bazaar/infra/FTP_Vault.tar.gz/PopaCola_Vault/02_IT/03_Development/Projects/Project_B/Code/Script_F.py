# Script F : Gestion des Stocks

import pandas as pd

def load_inventory_data(file_path):
    """Charge les données d'inventaire à partir d'un fichier CSV."""
    return pd.read_csv(file_path)

def check_stock_levels(inventory_data):
    """Vérifie les niveaux de stock et identifie les produits à réapprovisionner."""
    low_stock = inventory_data[inventory_data['quantity'] < 10]
    return low_stock

def generate_restock_report(low_stock):
    """Génère un rapport des produits à réapprovisionner."""
    report = low_stock[['product_name', 'quantity']]
    report_path = 'restock_report.csv'
    report.to_csv(report_path, index=False)
    print(f"Rapport de réapprovisionnement généré : {report_path}")

def main():
    inventory_data = load_inventory_data('inventory_data.csv')
    low_stock = check_stock_levels(inventory_data)
    generate_restock_report(low_stock)

if __name__ == "__main__":
    main()
