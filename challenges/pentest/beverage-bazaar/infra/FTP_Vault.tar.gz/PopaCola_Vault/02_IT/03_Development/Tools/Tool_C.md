# Outil C - Support Client

## Description
Un outil pour gérer les demandes de support client.

## Fonctionnalités
- Création et suivi des tickets.
- Base de connaissances intégrée.
- Chat en direct avec les clients.

## Technologies
- Développé en Ruby on Rails.
- Interface utilisateur en Vue.js.

## Installation
- Cloner le dépôt GitHub.
- Installer les dépendances avec `bundle install`.
- Lancer le serveur avec `rails server`.
