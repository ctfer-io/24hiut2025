# Plan de Test F - API

## Objectif
Valider les fonctionnalités et la sécurité de l'API.

## Cas de Test
- Création d'un nouvel utilisateur.
- Récupération des commandes d'un utilisateur.
- Authentification avec un token invalide.

## Prérequis
- Outil de test d'API (Postman).
- Environnement de test avec base de données.

## Résultats Attendus
- Les endpoints doivent répondre correctement.
- Les données doivent être cohérentes.
- Les accès non autorisés doivent être bloqués.
