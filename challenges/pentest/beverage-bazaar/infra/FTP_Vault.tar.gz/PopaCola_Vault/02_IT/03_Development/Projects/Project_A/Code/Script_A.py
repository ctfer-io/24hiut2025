# Script A : Analyse des Ventes

import pandas as pd

def load_sales_data(file_path):
    """Charge les données de ventes à partir d'un fichier CSV."""
    return pd.read_csv(file_path)

def calculate_total_sales(data):
    """Calcule le total des ventes."""
    return data['price'].sum()

def main():
    data = load_sales_data('sales_data.csv')
    total_sales = calculate_total_sales(data)
    print(f"Total des ventes : {total_sales} €")

if __name__ == "__main__":
    main()
