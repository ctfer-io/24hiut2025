# Documentation du Projet A

## Introduction
Le Projet A vise à améliorer l'efficacité de la chaîne d'approvisionnement de PopaCola.

## Objectifs
- Réduire les délais de livraison de 20%.
- Améliorer la traçabilité des produits.
- Optimiser les coûts de transport.

## Fonctionnalités
- Système de suivi en temps réel des livraisons.
- Intégration avec les fournisseurs pour une meilleure coordination.
- Tableau de bord pour analyser les performances.

## Technologies Utilisées
- Python pour le backend.
- React pour l'interface utilisateur.
- MongoDB pour la base de données.

## Installation
- Cloner le dépôt GitHub.
- Installer les dépendances avec `pip install -r requirements.txt`.
- Lancer le serveur avec `python app.py`.
