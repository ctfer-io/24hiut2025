# Plan de Test C

## Objectif
Évaluer la compatibilité mobile du site web.

## Cas de Test
1. Vérifier l'affichage sur différents appareils mobiles.
2. Tester la navigation et les interactions tactiles.
3. Vérifier le temps de chargement sur réseau mobile.

## Prérequis
- Accès à des appareils mobiles (iOS et Android).
- Connexion réseau mobile.

## Étapes
1. Ouvrir le site web sur différents appareils.
2. Naviguer sur les principales pages et vérifier l'affichage.
3. Tester les interactions tactiles (boutons, menus).
4. Mesurer le temps de chargement.

## Résultats Attendus
- Affichage correct sur tous les appareils testés.
- Navigation fluide et interactions réactives.
- Temps de chargement acceptable sur réseau mobile.
