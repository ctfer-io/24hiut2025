# Documentation du Projet B

## Introduction
Le Projet B concerne le développement d'une application mobile pour les clients de PopaCola.

## Objectifs
- Offrir une expérience utilisateur fluide.
- Permettre aux clients de commander des produits en ligne.
- Intégrer un programme de fidélité.

## Fonctionnalités
- Catalogue de produits avec descriptions et images.
- Panier d'achat et processus de paiement sécurisé.
- Suivi des commandes et historique des achats.

## Technologies Utilisées
- Flutter pour le développement multiplateforme.
- Firebase pour l'authentification et la base de données.
- Stripe pour les paiements en ligne.

## Installation
- Cloner le dépôt GitHub.
- Configurer Firebase et Stripe avec les clés API.
- Lancer l'application avec `flutter run`.
