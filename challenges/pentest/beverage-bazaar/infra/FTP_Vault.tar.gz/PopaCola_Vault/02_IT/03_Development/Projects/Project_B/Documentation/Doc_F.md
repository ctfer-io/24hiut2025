# Documentation du Projet B - API

## Introduction
L'API permet aux applications tierces d'interagir avec les services de PopaCola.

## Fonctionnalités
- Endpoints pour la gestion des utilisateurs et des commandes.
- Authentification basée sur les tokens JWT.
- Documentation Swagger pour les développeurs.

## Technologies
- Backend : Django
- Base de données : PostgreSQL
- Sécurité : OAuth 2.0

## Installation
- Cloner le dépôt GitHub.
- Installer les dépendances avec `pip install -r requirements.txt`.
- Configurer les variables d'environnement.
