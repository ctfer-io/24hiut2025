# Script C : Analyse des Performances du Site Web

import pandas as pd
import matplotlib.pyplot as plt

def load_performance_data(file_path):
    """Charge les données de performance à partir d'un fichier CSV."""
    return pd.read_csv(file_path)

def plot_performance_metrics(data):
    """Trace les métriques de performance du site web."""
    plt.figure(figsize=(10, 5))
    plt.plot(data['date'], data['page_load_time'], label='Temps de Chargement')
    plt.plot(data['date'], data['bounce_rate'], label='Taux de Rebond')
    plt.xlabel('Date')
    plt.ylabel('Valeurs')
    plt.title('Performance du Site Web')
    plt.legend()
    plt.show()

def main():
    data = load_performance_data('performance_data.csv')
    plot_performance_metrics(data)

if __name__ == "__main__":
    main()
