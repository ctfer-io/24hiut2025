# Plan de Test B

## Objectif
Tester le processus de commande en ligne.

## Cas de Test
1. Ajouter des produits au panier.
2. Passer à la caisse et remplir les informations de livraison.
3. Effectuer un paiement simulé.

## Prérequis
- Compte utilisateur de test.
- Produits disponibles dans le catalogue.

## Étapes
1. Ajouter différents produits au panier.
2. Vérifier la mise à jour du panier.
3. Accéder à la page de paiement et remplir les informations.
4. Simuler un paiement et vérifier la confirmation de commande.

## Résultats Attendus
- Les produits sont ajoutés correctement au panier.
- Les informations de livraison sont enregistrées.
- La confirmation de commande est reçue.
