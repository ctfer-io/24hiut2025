# Script E : Notification des Clients par Email

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email(subject, body, to_email):
    """Envoie un email aux clients avec les détails de la promotion."""
    from_email = "no-reply@popacola.com"
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_email
    msg['To'] = to_email
    msg.attach(MIMEText(body, 'plain'))

    with smtplib.SMTP('smtp.popacola.com', 587) as server:
        server.starttls()
        server.login(from_email, "password")
        server.sendmail(from_email, to_email, msg.as_string())

def main():
    subject = "Nouvelle Promotion PopaCola"
    body = "Découvrez nos offres exclusives !"
    send_email(subject, body, "client@example.com")

if __name__ == "__main__":
    main()
