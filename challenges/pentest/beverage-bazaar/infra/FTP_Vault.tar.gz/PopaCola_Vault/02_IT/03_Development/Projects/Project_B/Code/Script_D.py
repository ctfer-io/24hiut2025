# Script D : Analyse des Données de Vente

import pandas as pd
import matplotlib.pyplot as plt

def load_sales_data(file_path):
    """Charge les données de ventes à partir d'un fichier CSV."""
    return pd.read_csv(file_path)

def calculate_monthly_sales(data):
    """Calcule les ventes mensuelles."""
    data['date'] = pd.to_datetime(data['date'])
    return data.groupby(data['date'].dt.month)['price'].sum()

def plot_sales(monthly_sales):
    """Trace un graphique des ventes mensuelles."""
    monthly_sales.plot(kind='bar')
    plt.xlabel('Mois')
    plt.ylabel('Ventes')
    plt.title('Ventes Mensuelles')
    plt.show()

def main():
    data = load_sales_data('sales_data.csv')
    monthly_sales = calculate_monthly_sales(data)
    plot_sales(monthly_sales)

if __name__ == "__main__":
    main()
