# Outil A - Gestion des Tâches

## Description
Un outil pour organiser et suivre les tâches des équipes.

## Fonctionnalités
- Création et assignation de tâches.
- Suivi de l'avancement en temps réel.
- Notifications pour les échéances.

## Technologies
- Développé en Python avec Django.
- Interface utilisateur en React.

## Installation
- Cloner le dépôt GitHub.
- Installer les dépendances avec `pip install -r requirements.txt`.
- Lancer le serveur avec `python manage.py runserver`.
