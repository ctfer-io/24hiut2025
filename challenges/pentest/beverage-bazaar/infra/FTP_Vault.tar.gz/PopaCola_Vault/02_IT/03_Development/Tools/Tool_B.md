# Outil B - Analyse des Données

## Description
Un outil pour analyser les données de vente et de marketing.

## Fonctionnalités
- Tableaux de bord interactifs.
- Rapports personnalisables.
- Intégration avec les bases de données existantes.

## Technologies
- Backend : Flask
- Visualisation : D3.js
- Base de données : MySQL

## Installation
- Cloner le dépôt GitHub.
- Installer les dépendances avec `pip install -r requirements.txt`.
- Configurer la connexion à la base de données.
