# Plan de Test A

## Objectif
Vérifier la fonctionnalité de la page d'accueil du site web.

## Cas de Test
1. Vérifier que la page se charge en moins de 3 secondes.
2. Vérifier que tous les liens sont fonctionnels.
3. Vérifier l'affichage correct des images et des vidéos.

## Prérequis
- Accès à la version de test du site web.
- Navigateur web à jour.

## Étapes
1. Ouvrir la page d'accueil.
2. Mesurer le temps de chargement.
3. Cliquer sur chaque lien pour vérifier la redirection.
4. Vérifier l'affichage des médias.

## Résultats Attendus
- Temps de chargement < 3 secondes.
- Tous les liens fonctionnent correctement.
- Aucun problème d'affichage des médias.
