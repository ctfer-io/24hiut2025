# Documentation du Projet B - Interface Utilisateur

## Introduction
L'interface utilisateur est conçue pour offrir une expérience fluide et intuitive.

## Fonctionnalités
- Navigation simple et responsive.
- Accessibilité conforme aux normes WCAG.
- Thèmes personnalisables.

## Technologies
- Frontend : React
- Styles : CSS-in-JS avec styled-components
- Gestion d'état : Redux

## Installation
- Cloner le dépôt GitHub.
- Installer les dépendances avec `npm install`.
- Lancer l'application avec `npm start`.
