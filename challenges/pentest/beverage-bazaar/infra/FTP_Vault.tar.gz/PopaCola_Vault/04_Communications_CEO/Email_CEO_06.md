**De :** CEO de PopaCola
**À :** Équipe Juridique  
**Objet :** Conformité aux nouvelles régulations

Bonjour,

Merci de vérifier que nos pratiques commerciales et publicitaires respectent les nouvelles régulations en vigueur. Un rapport détaillé est attendu d'ici la fin du mois.

Cordialement,  
Le CEO
