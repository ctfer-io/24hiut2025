**De :** CEO de PopaCola
**À :** Équipe Marketing  
**Objet :** Bilan de la dernière campagne

Chers collaborateurs,

Notre dernière campagne publicitaire a rencontré un succès mitigé. Nous avons observé une hausse des ventes de 5 %, mais l'engagement sur les réseaux sociaux est inférieur à nos attentes. Nous devons analyser les retours des consommateurs et ajuster notre approche pour la prochaine campagne.

Cordialement,  
Le CEO
