**De :** CEO de PopaCola
**À :** Équipe R&D  
**Objet :** Idées pour un nouveau produit

Bonjour,

Suite aux tendances du marché, nous devons innover et proposer de nouvelles saveurs. J'attends vos suggestions pour une boisson qui pourrait concurrencer Read Boule sur le segment des sodas énergétiques.

Merci pour votre engagement,

Le CEO
