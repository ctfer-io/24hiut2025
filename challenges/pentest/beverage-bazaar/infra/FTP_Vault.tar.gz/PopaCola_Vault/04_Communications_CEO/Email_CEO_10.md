**De :** CEO de PopaCola
**À :** Équipe RSE
**Objet :** Renforcement de nos engagements écologiques

Bonjour,

Nous devons intensifier nos actions en faveur de l’environnement. Merci de proposer de nouvelles initiatives pour réduire notre empreinte carbone et améliorer le recyclage de nos emballages.

Cordialement,  
Le CEO
