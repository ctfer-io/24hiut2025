**De :** CEO de PopaCola
**À :** Équipe IT  
**Objet :** Modernisation des outils internes

Bonjour,

Notre infrastructure informatique doit évoluer pour mieux répondre aux besoins de nos équipes. Merci de proposer un plan de modernisation des outils collaboratifs et des serveurs.

Cordialement,  
Le CEO
