**De :** CEO de PopaCola
**À :** Équipe Sécurité Informatique  
**Objet :** Audit de sécurité

Bonjour,

Avec l'augmentation des cyberattaques, il est essentiel de renforcer notre sécurité informatique. Merci de mener un audit et de proposer des améliorations prioritaires.

Cordialement,  
Le CEO
