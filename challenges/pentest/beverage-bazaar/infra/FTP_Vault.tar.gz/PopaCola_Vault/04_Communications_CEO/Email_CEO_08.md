**De :** CEO de PopaCola
**À :** Équipe Commerciale  
**Objet :** Expansion vers de nouveaux marchés

Bonjour,

Nous devons étudier les opportunités d’exportation en dehors de notre marché principal. Merci d’élaborer une analyse des pays cibles et des stratégies adaptées.

Bien à vous,  
Le CEO
