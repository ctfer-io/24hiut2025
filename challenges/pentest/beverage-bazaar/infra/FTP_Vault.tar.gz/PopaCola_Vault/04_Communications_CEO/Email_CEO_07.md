**De :** CEO de PopaCola
**À :** Équipe Qualité  
**Objet :** Amélioration des contrôles qualité

Bonjour,

Nous avons reçu quelques retours clients signalant des variations de goût sur certaines productions. Merci de renforcer les contrôles qualité et d’identifier les causes possibles.

Cordialement,  
Le CEO
