**De :** CEO de PopaCola
**À :** Département RH  
**Objet :** Recrutement de nouveaux talents

Bonjour,

Notre croissance rapide nécessite le recrutement de profils spécialisés en marketing digital et en production. Merci d'établir un plan de recrutement pour les six prochains mois.

Bien à vous,  
Le CEO
