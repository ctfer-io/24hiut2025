**De :** CEO de PopaCola
**À :** Équipe Logistique  
**Objet :** Optimisation de la chaîne d'approvisionnement

Bonjour,

Nous avons constaté des retards dans la distribution de nos produits. Merci d'identifier les goulots d'étranglement et de proposer des solutions pour fluidifier notre chaîne d'approvisionnement.

Cordialement,  
Le CEO
